<?php
require_once ('koneksi.php');
$user = $_POST['userid'];
$pass = md5($_POST['password']);
$nama_lengkap = $_POST['nama_lengkap'];
$cekuser = mysql_query("SELECT * FROM user WHERE userid = '$user'");
if ( mysql_num_rows($cekuser) <> 0 ) {
    echo "<script> alert ('ID Sudah Terdaftar, Silahkan Login');
document.location.href='daftar.php'</script>\n"; 
} else {
    if ( !$user || !$pass ) {
        echo "<script> alert ('Silahkan Lengkapi data Anda, Jangan Sampai Ada Yang Kosong !!! ');
document.location.href='daftar.php'</script>\n"; 
    } else {
        $simpan = mysql_query("INSERT INTO user VALUES('$user','$pass','$nama_lengkap')");
        if ($simpan) {
echo "<script> alert ('Pendaftaran Berhasil');
document.location.href='index.php'</script>\n"; 
       } else {
            echo "<script> alert ('Registrasi Gagal');
document.location.href='daftar.php'</script>\n";
        }
    }
}
?>