<?php
include "../koneksi.php";

$nis=$_POST['nis'];
$nama =$_POST['nama'];
$tempat_lahir=$_POST['tempat_lahir'];
$tgl_lahir=$_POST['tgl_lahir'];
$alamat =$_POST['alamat'];
$telepon =$_POST['telepon'];


$query= mysql_query("INSERT INTO siswa (nis, nama, tempat_lahir, tgl_lahir, alamat, telepon) VALUES ('$nis','$nama','$tempat_lahir','$tgl_lahir','$alamat','$telepon')");
if ($query) {
echo "<script> alert ('Data berhasil disimpan');
document.location.href='siswa.php'</script>\n";
echo "<script> alert ('Data gagal disimpan');
document.location.href='tambahsiswa.php'</script>\n";
}
?>