<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/styles.css">
<link rel="stylesheet" href="../css/login.css">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="../css/script.js"></script>
<link href="../css/bootstrap.min.css" rel="stylesheet">
<title>Website Akademik Guru</title>


<script type="text/javascript" src="../JS/jquery-1.3.2.js"></script>
<script type="text/javascript" src="../JS/ui.core.js"></script>
<link type="text/css" href="../JS/themes/base/ui.all.css" rel="stylesheet" /> 



<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>


<style = type="text/css">
body {
	background-image: url(../gambar/);
	}
	</style>
   </head>
<body>

<div id="wrap">

<div id="header">
<img src="../gambar/banner.png" width="1280" height="254">
</div>

<div id='cssmenu'>
<ul>
   <li><a href='user.php'>Beranda Admin</a></li>
   <li><a href='siswa.php'>Mahasiswa</a>
    <ul>
         <li><a href='tambah_siswa.php'>Tambah Siswa</a>
  </ul>
   </li>
   <li><a href='matkul.php'>Mata Kuliah</a>
   <ul>
         <li><a href='tambahmatkul.php'>Tambah Mata Kuliah</a>
  </ul>
   </li>
   <li><a href='nilai.php'>Nilai</a>
   <ul>
         <li><a href='#'>Tambah Nilai</a>
  </ul>
   </li>
   <li><a href='keluar.php'>Keluar</a></li>
   </ul>
</div>
<div id="sidebar">
<div id="box">
<?php
session_start();
if(!isset($_SESSION['userid'])) {
   header('location:login.php'); 
} else { 
   $usr = $_SESSION['userid']; 
   }
require_once('../koneksi.php');
$query = mysql_query("SELECT nama_lengkap FROM user WHERE userid = '$usr'");
$hasil = mysql_fetch_array($query);
?>

<title>Halaman Sukses Login</title>

<div align='center'>
   Selamat Datang, <b><?php echo $hasil[0];?></b> 
</div>
</div>
</div>

<div id="content">
<br></br>
<br></br>
<p>
<table class="table" style="font-size:18px; font-family:'Times New Roman', Times, serif;">
<form action="prosestambahnilai.php" method="post">
<tr>
    <th colspan="4" style="font-size:20px"><center>Tambah Nilai</center></td>
  </tr>
  <tr>
   <td>NIS</td>
   <td>:</td>
   <td><select name="nis" id="nis" style="width:150px;" class="form-control" required>
    <option>--Pilih NIS--</option>
   <?php
      mysql_connect("localhost","root","");
      mysql_select_db("sisfo");

      // tampilkan nama-nama propinsi yang ada di database
      $sql = mysql_query("SELECT nis FROM siswa");
      while($p=mysql_fetch_array($sql)){
         echo "<option value=$p[nis]>$p[nis]</option> \n";
      }
     ?>
   </select></td>
  </tr>
  <tr>
   <td>Kode Mata Kuliah</td>
   <td>:</td>
   <td><select name="kd_matkul" id="kd_matkul" style="width:150px;" class="form-control" required>
    <option>--Pilih Kode--</option>
   <?php
      mysql_connect("localhost","root","");
      mysql_select_db("sisfo");

      // tampilkan nama-nama propinsi yang ada di database
      $sql = mysql_query("SELECT kd_matkul FROM matkul");
      while($p=mysql_fetch_array($sql)){
         echo "<option value=$p[kd_matkul]>$p[kd_matkul]</option> \n";
      }
     ?>
   </select></td>
  </tr>
<tr>
   <td>Nilai Absen</td>
   <td>:</td>
   <td><input type="text" name="absen" style="width:100px;" id="absen" class="form-control" placeholder="Nilai Absen">
   </td>
  </tr>
  <tr>
   <td>Nilai Tugas</td>
   <td>:</td>
   <td><input type="text" name="tugas" style="width:100px;" id="tugas" class="form-control" placeholder="Nilai Tugas"></td>
  </tr>
  <tr>
   <td>Nilai UTS</td>
   <td>:</td>
   <td><input type="text" name="uts" style="width:100px;" id="uts" class="form-control" placeholder="Nilai UTS"></td>
  </tr>
  <tr>
   <td>Nilai UAS</td>
   <td>:</td>
   <td><input type="text" name="uas" style="width:100px;" id="uas" class="form-control" placeholder="Nilai UAS"></td>
  </tr>
  <tr>
  <td></td>
    <td colspan="2" align="left"><br><input name="Submit" type="submit" value="Simpan" style="width:100px;" class="btn btn-primary"/>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
     <input value="Batal" type="button" onClick="window.location.href='nilai.php'" style="width:100px;" class="btn btn-danger">
    </br>
    </td>
  </tr>
</form>
</table>
</p>
<br>
</p>
<br>
</div>


<div id="footer">
<br></br>
<p><b>Copyright 2016 || Sistem Informasi Guru
    </b>  </p>
</div>
</div>

</body>
</html>