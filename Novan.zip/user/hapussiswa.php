<?php 
include "../koneksi.php";

$id = $_GET['id'];

$query = mysql_query("delete from siswa where id='$id'") or die(mysql_error());

if ($query) {
	header('location:siswa.php');
}
?>