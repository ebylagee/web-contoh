<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/styles.css">
<link rel="stylesheet" href="../css/login.css">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="../css/script.js"></script>
<link href="../css/bootstrap.min.css" rel="stylesheet">
<title>Website Akademik Guru</title>


<script type="text/javascript" src="../JS/jquery-1.3.2.js"></script>
<script type="text/javascript" src="../JS/ui.core.js"></script>
<script type="text/javascript" src="../JS/ui.datepicker.js"></script>
<link type="text/css" href="../JS/themes/base/ui.all.css" rel="stylesheet" /> 



<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script type="text/javascript"> 
       $(document).ready(function(){
        $("#tgl_lahir").datepicker({
		dateFormat  : "yy-mm-dd", 
          changeMonth : true,
          changeYear  : true,
		  yearRange	  : "-50:+0"

        });
      });
	  
    </script>


<style = type="text/css">
body {
	background-image: url(../gambar/);
	}
	</style>
   </head>
<body>

<div id="wrap">

<div id="header">
<img src="../gambar/banner.png" width="1280" height="254">
</div>

<div id='cssmenu'>
<ul>
   <li><a href='user.php'>Beranda Admin</a></li>
   <li><a href='siswa.php'>Mahasiswa</a>
    <ul>
         <li><a href='#'>Tambah Siswa</a>
  </ul>
   </li>
   <li><a href='matkul.php'>Mata Kuliah</a>
   <ul>
         <li><a href='tambahmatkul.php'>Tambah Mata Kuliah</a>
  </ul>
   </li>
   <li><a href='nilai.php'>Nilai</a>
   <ul>
         <li><a href='tambahnilai.php'>Tambah Nilai</a>
  </ul>
   </li>
   <li><a href='keluar.php'>Keluar</a></li>
   </ul>
</div>
<div id="sidebar">
<div id="box">
<?php
session_start();
if(!isset($_SESSION['userid'])) {
   header('location:login.php'); 
} else { 
   $usr = $_SESSION['userid']; 
   }
require_once('../koneksi.php');
$query = mysql_query("SELECT nama_lengkap FROM user WHERE userid = '$usr'");
$hasil = mysql_fetch_array($query);
?>

<title>Halaman Sukses Login</title>

<div align='center'>
   Selamat Datang, <b><?php echo $hasil[0];?></b> 
</div>
</div>
</div>

<div id="content">
<br></br>
<center><p>
  <div class="body">   
<br />
<p style="font-size:30px; font-family:'Arial Black', Times, serif;">Tambah Siswa</p>
<br></br>
<form action="prosestambahsiswa.php" style="font-size:14px; font-family:'Times New Roman', Times, serif;" method="post" class="form-horizontal">
	<div class="form-group">
		<label class="control-label col-lg-2">NIS</label>
	<div class="col-lg-4">
		<input type="text" required class="form-control" id="nis" name="nis" placeholder="NIS"/>
	</div>
	</div>
    <div class="form-group">
		<label class="control-label col-lg-2">Nama Siswa</label>
	<div class="col-lg-4">
		<input type="text" required class="form-control" id="nama" name="nama" placeholder="Nama Lengkap"/>
	</div>
	</div>
    <div class="form-group">
		<label class="control-label col-lg-2">Tempat/Tanggal Lahir</label>
	<div class="col-lg-4">
		<input type="text" required class="form-control" id="tempat_lahir" name="tempat_lahir" placeholder="Tempat Lahir"/>
	</div>
    <div class="col-lg-4">
		<input type="text" required class="form-control" id="tgl_lahir" name="tgl_lahir" placeholder="Tanggal Lahir"/>
	</div>
	</div>
	<div class="form-group">
		<label class="control-label col-lg-2">Alamat</label>
	<div class="col-lg-4">
		<textarea required class="form-control" id="alamat" name="alamat" placeholder="Alamat"/></textarea>
	</div>
    </div>
	<div class="form-group">
		<label class="control-label col-lg-2">Telepon</label>
	<div class="col-lg-4">
		<input type="text" required class="form-control" id="telepon" name="telepon" placeholder="Telepon"/>
	</div>
	</div>
    <br></br>
	<div class="form-actions no-margin-bottom" style="text-align:center;">
		<input type="submit" name="button" value="Simpan" class="btn btn-primary" />&nbsp;&nbsp;&nbsp;
        <input type="button" name="batal" value="Batal" onClick="window.location.href='siswa.php'" class="btn btn-danger" />
	</div>

</form>
</div>
  </p>
</left>
<br>
</p>
<br>
</div>


<div id="footer">
<br></br>
<p><b>Copyright 2016 || Sistem Informasi Guru
    </b>  </p>
</div>
</div>

</body>
</html>