<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/styles.css">
<link rel="stylesheet" href="../css/login.css">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="../css/script.js"></script>
<title>Website Akademik Guru</title>
<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<style = type="text/css">
body {
	background-image: url(../gambar/);
	}
	</style>
   </head>
<body>

<div id="wrap">

<div id="header">
<img src="../gambar/banner.png" width="1280" height="254">
</div>

<div id='cssmenu'>
<ul>
   <li><a href='user.php'>Beranda Admin</a></li>
   <li><a href='siswa.php'>Mahasiswa</a>
    <ul>
         <li><a href='tambah_siswa.php'>Tambah Siswa</a>
  </ul>
   </li>
   <li><a href='#'>Mata Kuliah</a>
   <ul>
         <li><a href='tambahmatkul.php'>Tambah Mata Kuliah</a>
  </ul>
   </li>
   <li><a href='nilai.php'>Nilai</a>
   <ul>
         <li><a href='tambahnilai.php'>Tambah Nilai</a>
  </ul>
   </li>
   <li><a href='keluar.php'>Keluar</a></li>
   </ul>
</div>
<div id="sidebar">
<div id="box">

<?php
session_start();
if(!isset($_SESSION['userid'])) {
   header('location:login.php'); 
} else { 
   $usr = $_SESSION['userid']; 
   }
require_once('../koneksi.php');
$query = mysql_query("SELECT nama_lengkap FROM user WHERE userid = '$usr'");
$hasil = mysql_fetch_row($query);
?>

<title>Halaman Sukses Login</title>

<div align='center'>
   Selamat Datang, <b><?php echo $hasil[0];?></b> 
</div>
</div>
</div>

<div id="content">
<br></br>
<center><p style="font-size:20px">
<b>Mata Kuliah</b>
</p></center>


<p><center>
<?php
include "../koneksi.php";

$query= mysql_query("select * from matkul");
$no=0;

if(mysql_num_rows($query) == 0) {
     echo "\n";
	 echo "Mata Kuliah Belum Tersedia";
   } else {

echo "<table class='table' style='font-size:18px; font-family:Times New Roman, Times, serif'; cellpadding=5 align=center border=1px>
<tr bgcolor=#3fe24d><th><center>No</center></th><th><center>Kode Mata Kuliah</center></th><th><center>Nama Mata Kuliah</center></th><th><center>SKS</center></th><th><center>Dosen</center></th><th><center>Aksi</center></th></tr>";
   
while($data=mysql_fetch_array($query)){
$no++;

echo "<tr>
<td style='width:10px;'><center>$no</center></td>
<td  style='width:135px;'><center>$data[kd_matkul]</center></td>
<td><center>$data[nama_matkul]</center></td>
<td style='width:10px;'><center>$data[sks]</center></td>
<td><center>$data[dosen]</center></td>
<td style='width:116px;'> 
<a href='editmatkul.php?id=$data[id]' style='text-decoration:none'><input type='button' value='Edit' class='btn btn-success btn-sm'>
<a href='hapusmatkul.php?id=$data[id]' style='text-decoration:none'><input type='button' value='Hapus' class='btn btn-danger btn-sm'>
</td>
</tr>";
}
}
?>
</center></p>
</table>
</div>

<div id="footer">
<br></br>
<p><b>Copyright 2016 || Sistem Informasi Guru
    </b>  </p>
</div>
</div>

</body>
</html>