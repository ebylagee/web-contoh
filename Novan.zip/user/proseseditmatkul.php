<?php ob_start();
include "../koneksi.php";
$kd_matkul =$_POST['kd_matkul'];
$nama_matkul =$_POST['nama_matkul'];;
$sks =$_POST['sks'];
$dosen =$_POST['dosen'];

$query= mysql_query("update matkul set kd_matkul='$kd_matkul', nama_matkul='$nama_matkul', sks='$sks', dosen='$dosen' where id='$_GET[id]'");
if ($query) {
echo "<script> alert ('Data berhasil disimpan');
document.location.href='matkul.php'</script>\n";
}else{
echo "<script> alert ('Data gagal disimpan');
document.location.href='matkul.php'</script>\n";
}
?>