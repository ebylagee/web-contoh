<?php
include "../koneksi.php";

$nis=$_POST['nis'];
$kd_matkul=$_POST['kd_matkul'];
$absen=$_POST['absen'];
$tugas=$_POST['tugas'];
$uts=$_POST['uts'];
$uas=$_POST['uas'];
$nakhir=(($absen*0.10)+($tugas*0.20)+($uts*0.30)+($uas*0.40));
$gradenilai=
		$gradenilai;
		if($nakhir <= 40)
		{
			$gradenilai= 'E';
		}
		else if($nakhir <= 60)
		{
			$gradenilai= 'D';
		}
		else if($nakhir <= 70)
		{
			$gradenilai= 'C';
		}
		else if($nakhir <= 80)
		{
			$gradenilai= 'B';
		}
		else if($nakhir <= '100' )
		{
			$gradenilai= 'A';
		}
		
$query=mysql_query("INSERT INTO nilai (nis, kd_matkul, absen, tugas, uts, uas, akhir, grade) VALUES ('$nis','$kd_matkul','$absen','$tugas','$uts','$uas','$nakhir','$gradenilai')");
if ($query) {
echo "<script> alert ('Data berhasil disimpan');
document.location.href='nilai.php'</script>\n";
echo "<script> alert ('Data gagal disimpan');
document.location.href='tambahnilai.php'</script>\n";
}
?>