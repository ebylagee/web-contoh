<?php ob_start();
include "../koneksi.php";
$nis =$_POST['nis'];
$nama =$_POST['nama'];;
$tempat_lahir =$_POST['tempat_lahir'];
$tgl_lahir =$_POST['tgl_lahir'];
$alamat =$_POST['alamat'];
$telepon =$_POST['telepon'];

$query= mysql_query("update siswa set nis='$nis', nama='$nama', tempat_lahir='$tempat_lahir', tgl_lahir='$tgl_lahir', alamat='$alamat', telepon='$telepon' where id='$_GET[id]'");
if ($query) {
echo "<script> alert ('Data berhasil disimpan');
document.location.href='siswa.php'</script>\n";
}else{
echo "<script> alert ('Data gagal disimpan');
document.location.href='siswa.php'</script>\n";
}
?>