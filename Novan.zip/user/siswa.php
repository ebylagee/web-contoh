<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/styles.css">
<link rel="stylesheet" href="../css/login.css">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="../css/script.js"></script>
<title>Website Akademik Guru</title>
<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<style = type="text/css">
body {
	background-image: url(../gambar/);
	}
	</style>
   </head>
<body>

<div id="wrap">

<div id="header">
<img src="../gambar/banner.png" width="1280" height="254">
</div>

<div id='cssmenu'>
<ul>
   <li><a href='user.php'>Beranda Admin</a></li>
   <li><a href='#'>Mahasiswa</a>
    <ul>
         <li><a href='tambah_siswa.php'>Tambah Siswa</a>
  </ul>
   </li>
   <li><a href='matkul.php'>Mata Kuliah</a>
   <ul>
         <li><a href='tambahmatkul.php'>Tambah Mata Kuliah</a>
  </ul>
   </li>
   <li><a href='nilai.php'>Nilai</a>
   <ul>
         <li><a href='tambahnilai.php'>Tambah Nilai</a>
  </ul>
   </li>
   <li><a href='keluar.php'>Keluar</a></li>
   </ul>
</div>
<div id="sidebar">
<div id="box">

<?php
session_start();
if(!isset($_SESSION['userid'])) {
   header('location:login.php'); 
} else { 
   $usr = $_SESSION['userid']; 
   }
require_once('../koneksi.php');
$query = mysql_query("SELECT nama_lengkap FROM user WHERE userid = '$usr'");
$hasil = mysql_fetch_row($query);
?>

<title>Halaman Sukses Login</title>

<div align='center'>
   Selamat Datang, <b><?php echo $hasil[0];?></b> 
</div>
</div>
</div>

<div id="content">
<br></br>
<center><p style="font-size:20px">
<b>Data Siswa</b>
</p></center>


<p><center>
<?php
include "../indo.php";
include "../koneksi.php";

$query= mysql_query("select * from siswa");
$no=0;

if(mysql_num_rows($query) == 0) {
     echo "\n";
	 echo "Siswa Belum Tersedia";
   } else {

echo "<table class='table' style='font-size:18px; font-family:Times New Roman, Times, serif'; cellpadding=5 align=center border=1px>
<tr bgcolor=#3fe24d><th><center>No</center></th><th><center>NIS</center></th><th><center>Nama</center></th><th><center>Tempat Lahir</center></th><th><center>Tanggal Lahir</center></th><th><center>Alamat</center></th><th><center>Telepon</center></th><th><center>Aksi</center></th></tr>";
   
while($data=mysql_fetch_array($query)){
$tanggal = tgl_indo($data['tgl_lahir']);
$no++;

echo "<tr>
<td><center>$no</center></td>
<td><center>$data[nis]</center></td>
<td><center>$data[nama]</center></td>
<td><center>$data[tempat_lahir]</center></td>
<td><center>$tanggal</center></td>
<td><center>$data[alamat]</center></td>
<td><center>$data[telepon]</center></td>
<td style='width:116px;'> 
<a href='editsiswa.php?id=$data[id]' style='text-decoration:none'><input type='button' value='Edit' class='btn btn-success  btn-sm'>
<a href='hapussiswa.php?id=$data[id]' style='text-decoration:none'><input type='button' value='Hapus' class='btn btn-danger  btn-sm'>
</td>
</tr>";
}
}
?>
</center></p>
</table>
</div>

<div id="footer">
<br></br>
<p><b>Copyright 2016 || Sistem Informasi Guru
    </b>  </p>
</div>
</div>

</body>
</html>