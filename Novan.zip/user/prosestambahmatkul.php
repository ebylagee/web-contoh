<?php
include "../koneksi.php";

$kd_matkul=$_POST['kd_matkul'];
$nama_matkul =$_POST['nama_matkul'];
$sks=$_POST['sks'];
$dosen=$_POST['dosen'];

$query= mysql_query("INSERT INTO matkul (kd_matkul, nama_matkul, sks, dosen) VALUES ('$kd_matkul','$nama_matkul','$sks','$dosen')");
if ($query) {
echo "<script> alert ('Data berhasil disimpan');
document.location.href='matkul.php'</script>\n";
echo "<script> alert ('Data gagal disimpan');
document.location.href='tmabahmatkul.php'</script>\n";
}
?>