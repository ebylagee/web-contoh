<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/styles.css">
<link rel="stylesheet" href="../css/login.css">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="../css/script.js"></script>
<title>Website Akademik Guru</title>
<style = type="text/css">
body {
	background-image: url(../gambar/);
	}
	</style>
   </head>
<body>

<div id="wrap">

<div id="header">
<img src="../gambar/banner.png" width="1280" height="254">
</div>

<div id='cssmenu'>
<ul>
   <li><a href='user.php'>Beranda Admin</a></li>
   <li><a href='siswa.php'>Mahasiswa</a>
    <ul>
         <li><a href='tambah_siswa.php'>Tambah Siswa</a>
  </ul>
   </li>
   <li><a href='matkul.php'>Mata Kuliah</a>
   <ul>
         <li><a href='tambahmatkul.php'>Tambah Mata Kuliah</a>
  </ul>
   </li>
   <li><a href='nilai.php'>Nilai</a>
   <ul>
         <li><a href='tambahnilai.php'>Tambah Nilai</a>
  </ul>
   </li>
   <li><a href='keluar.php'>Keluar</a></li>
   </ul>
</div>
<div id="sidebar">
<div id="box">

<?php
session_start();
if(!isset($_SESSION['userid'])) {
   header('location:login.php'); 
} else { 
   $usr = $_SESSION['userid']; 
   }
require_once('../koneksi.php');
$query = mysql_query("SELECT nama_lengkap FROM user WHERE userid = '$usr'");
$hasil = mysql_fetch_row($query);
?>

<title>Halaman Sukses Login</title>

<div align='center'>
   Selamat Datang, <b><?php echo $hasil[0];?></b> 
</div>
</div>
</div>

<div id="content">
<br>
<center> <p style="font-size:40px; color:#ea8c10;"><marquee><b>
Selamat Datang di Halaman Admin
</b></marquee></p></center>

<center><img src="../gambar/background5.png" align="center" width="600"/> </center>

</div>

<div id="footer">
<br></br>
<p><b>Copyright 2016 || Sistem Informasi Guru
    </b>  </p>
</div>
</div>

</body>
</html>