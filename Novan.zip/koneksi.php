<?php 
$host="localhost";
$username="root";
$password="";
$database="sisfo";

$koneksi=mysql_connect($host,$username,$password) or die (mysql_error());
mysql_select_db($database,$koneksi) or die (mysql_error());
?>