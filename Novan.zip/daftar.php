<!doctype html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/login.css">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="css/script.js"></script>
<link href="css/bootstrap.min.css" rel="stylesheet">
<title>Website Akademik Guru</title>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<style = type="text/css">
body {
	background-image: url(gambar/);
	}
	</style>
   </head>
<body>

<div id="wrap">

<div id="header">
<img src="gambar/banner.png" width="1280" height="254">
</div>

<div id='cssmenu'>
<ul>
   <li><a href='index.php'>Halaman Utama</a></li>
      <li><a href='about.php'>Tentang</a></li>
   </ul>
</div>

<?php
  session_start();
  if(isset($_SESSION['userid'])) {
  header('location:index.php'); }
?> 
<br></br>
<p>Silahkan Melakukan Registrasi</p>
<p>Harap Di Isi Dengan Benar. Jangan Sampai Lupa User Id dan Password Anda. Terima Kasih.</p>
<table class="table ">
<form action="prosesdaftar.php" method="post">
  <tr>
    <th colspan="4" style="font-size:20px"><center>Registrasi Member</center></td>
  </tr>
  <tr>
   <td>User ID </td>
    <td><input type="text" name="userid" style="width:300px;" class="form-control" placeholder="User ID"/></td>
  </tr>
  <tr>
    <td>Nama Lengkap </td>
    <td><input name="nama_lengkap" type="text" style="width:300px;" class="form-control" placeholder="Nama Lengkap" /></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input type="password" name="password" style="width:300px;" class="form-control" placeholder="Password"/></td>
  </tr>
  <tr>
    <td colspan="4">				    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="Submit" type="submit" value="Daftar"  class="btn btn-primary"/>&nbsp;&nbsp;&nbsp; 
    <input value="Batal" type="button" onClick="window.location.href='index.php'" class="btn btn-danger"></td>
  </tr>
</form>
</table>


<div id="footer">
<br></br>
<p><b>Copyright 2016 || Sistem Informasi Guru
</b>  </p>
</div>
</div>


</body>
<html>
