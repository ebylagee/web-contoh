<?php
session_start();
require_once ('koneksi.php');
$user = $_POST['userid'];
$pass = md5($_POST['password']);
$cekuser = mysql_query("SELECT * FROM user WHERE userid = '$user'");
$jumlah = mysql_num_rows($cekuser);
$hasil = mysql_fetch_array($cekuser);
 if(!$user || !$pass) {
    echo "<script> alert('Data masih ada yang kosong');
	document.location.href='index.php'</script>\n";
 } else {
if ( $jumlah == 0 ) {
    echo "<script> alert ('User ID Belum Terdaftar');
document.location.href='index.php'</script>\n";
} else {
    if ( $pass <> $hasil['password'] ) {
       echo "<script> alert ('Password Salah');
document.location.href='index.php'</script>\n";
    } else {
        $_SESSION['userid'] = $hasil['userid'];
        header('location:user/user.php');
    }
}
}
?>