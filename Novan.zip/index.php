<!doctype html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/login.css">


<link href="css/bootstrap.min.css" rel="stylesheet">
<title>Website Akademik Guru</title>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style = type="text/css">
body {
	background-image: url(gambar/);
	}
	</style>
	<script src="JS/jquery-1.8.0.min.js"></script> 
<script src="JS/headline.js"></script>
<script type="text/javascript"> 
      $(document).ready(function(){
	  		// untuk permulaan, tampilkan content nomor 1 '#slideAwal'
	  		bukaContent($('#slideAwal'),'div1');					
	    });
</script>
   </head>
<body>

<div id="wrap">

<div id="header"><img src="gambar/banner.png" width="1280" height="254"></div>

<div id='cssmenu'>
<ul>
   <li><a href='index.php'>Beranda</a></li>
      <li><a href='about.php'>Tentang</a></li>
   </ul>
</div>

<div id="sidebar">

<div id="box">
<p>
<br>
Silahkan Login Terlebih Dahulu Untuk Masuk</p>
<form action="proseslogin.php" method="post">
  <div class="form">
<form class="login-form">
<p>Login Member</p>
      <input name="userid" type="text" style="width:110px; height:50px;"  class="form-control" placeholder="username"/>
      <input name="password" type="password" style="width:110px; height:50px;" class="form-control" placeholder="password"/>
      <button>login</button>
       <p class="message">Belum Registrasi?  Daftar <a href="daftar.php">Disini</a></p>
    </form>
	</form>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="js/index.js"></script>
</div> 
</div>

<div id="content">
<br></br>
<center> <p style="font-size:40px; color:#ea8c10;"><marquee><b>
Selamat Datang di Halaman Website Sistem Informasi Akademik Mahasiswa Online
</b></marquee></p></center>

<div id="headline">
	<div id="divContent">
	  <div id="div1">
 	     <center><img src="gambar/background1.png" align="center" width="600"/> </center>
		</div>
        
      <div id="div2">
 	      <center><img src="gambar/background2.png" align="center" width="600"/> </center>
		</div>
      <div id="div3">
 	      <center><img src="gambar/background3.png" align="center" width="600"/> </center>
		</div>  
		
    </div>
	<div id="divTrigger">
      <a href="javascript:;" onClick="bukaContent(this,'div1')" id="slideAwal"> </a>
      <a href="javascript:;" onClick="bukaContent(this,'div2')"> </a>
	    <a href="javascript:;" onClick="bukaContent(this,'div3')"> </a>
	</div>
</div>
</div>

<div id="footer">
<br></br>
  <p><b>Copyright 2016 || Sistem Informasi Guru
    </b>  </p>
</div>
</div>

</body>
<html>
