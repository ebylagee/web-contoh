<!doctype html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/login.css">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="css/script.js"></script>
<link href="css/bootstrap.min.css" rel="stylesheet">
<title>Website Akademik Guru</title>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style = type="text/css">
body {
	background-image: url(gambar/);
	}
	</style>
   </head>
<body>

<div id="wrap">

<div id="header">
<img src="gambar/banner.png" width="1280" height="254">
</div>

<div id='cssmenu'>
<ul>
   <li><a href='index.php'>Beranda</a></li>
</ul>
</div>

<div id="sidebar">
<div id="box">
<p>
<br>
Silahkan Login Terlebih Dahulu Untuk Masuk</p>
<form action="proseslogin.php" method="post">
  <div class="form">
<form class="login-form">
<p>Login Member</p>
      <input name="userid" type="text" style="width:110px; height:50px;"  class="form-control" placeholder="username"/>
      <input name="password" type="password" style="width:110px; height:50px;"  class="form-control" placeholder="password"/>
      <button>login</button>
      <p class="message">Belum Registrasi?  Daftar <a href="daftar.php">Disini</a></p>
    </form>
	</form>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="js/index.js"></script>
</div>
</div> 

<div id="content">
<center>
<br></br>
<p style="font-size:40px"><b>Tentang</b></p>
</p></center>
<p>
<br></br>
<p> <center><img src="gambar/background4.jpg" align="center" width="400"/> </center><p>

<p style="font-size:30px; font-family:'Times New Roman', Times, serif;">
Website ini dibuat untuk memudahkan guru - guru untuk memasukkan nilai para siswa kedalam database yang dapat diakses kapanpun dan dimanapun, website ini menampilkan mata kuliah, nilai, dll yang berhubungan dengan sistem informasi guru.
<p><center>

</center></p>
</div>

<div id="footer">
<br></br>
  <p><b>Copyright 2016 || Sistem Informasi Guru
    </b>  </p>
</div>
</div>
</body>
<html>
